var score = 0;
var q1_score = 0;
var q2_score = 0;

$(document).ready(function () {
    $('#q2').hide();
    $('#err1').hide();
    $('#err2').hide();

    $('#q1').click(function () {
        if ($('#q1a1').is(':checked')) { $('#q2').fadeIn(300); }
        else { $('#q2').hide(); }
        //$('#q2').fadeIn(300)
        //return false
    })

    $('#submit').click(function () {

        if (!($('#q1a1').is(':checked') || $('#q1a2').is(':checked') || $('#q1a3').is(':checked'))) {
            $('#err1').fadeIn(300);
        }
        else {
            if ($('#q1a1').is(':checked') && !($('#q2a1').is(':checked') || $('#q2a2').is(':checked') || $('#q2a3').is(':checked'))) {
                $('#err2').fadeIn(300);
            }
            else {

                if ($('#q1a1').is(':checked')) { q1_score = 100 }
                else if ($('#q1a2').is(':checked')) { q1_score = 50 }
                else if ($('#q1a3').is(':checked')) { q1_score = 0 }

                if ($('#q2a1').is(':checked')) { q2_score += 50 }
                if ($('#q2a2').is(':checked')) { q2_score += 50 }
                if ($('#q2a3').is(':checked')) { q2_score += 25 }

                score = q1_score + q2_score;


                if (score < 0 || score > 225) {
                    location.reload()
                } else {

                    fetch('https://api/SendToServer', {
                        method: 'POST',
                        body: JSON.stringify({ score }),
                        headers: {
                            'Content-type': 'application/json; charset=UTF-8',
                        },
                    })
                        .then((response) => response.json())
                        .then((json) => console.log(json));

                    q1_score = 0;
                    q2_score = 0;
                }
            }
        }

    })

    $('#skip').click(function () {
        location.reload();
    })

})